package com.example.ledcontrol

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private val esp8266Ip = "http://192.168.0.214" // 🔁 Replace with your ESP8266 IP
    private val TAG = "ESP_LOGS"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonOn: Button = findViewById(R.id.buttonOn)
        val buttonOff: Button = findViewById(R.id.buttonOff)

        buttonOn.setOnClickListener {
            Log.d(TAG, "LED ON button clicked")
            sendCommand("/on")
        }

        buttonOff.setOnClickListener {
            Log.d(TAG, "LED OFF button clicked")
            sendCommand("/off")
        }
    }

    private fun sendCommand(command: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val fullUrl = "$esp8266Ip$command"
                Log.d(TAG, "Sending request to: $fullUrl")

                val url = URL(fullUrl)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 3000
                connection.readTimeout = 3000

                val responseCode = connection.responseCode
                Log.d(TAG, "HTTP Response Code: $responseCode")

                val response = connection.inputStream.bufferedReader().use { it.readText() }
                Log.d(TAG, "Response from ESP8266: $response")

                runOnUiThread {
                    Toast.makeText(this@MainActivity, response, Toast.LENGTH_SHORT).show()
                }

            } catch (e: Exception) {
                Log.e(TAG, "Error sending request: ${e.message}", e)
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
